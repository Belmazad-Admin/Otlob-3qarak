# Claude Code project guide — belmazad.com Request a Property

You are continuing an existing working front-end prototype. Preserve its core model and visual direction unless Mahmoud asks for a change. The product is a reverse property marketplace: buyers publish demand; owners and brokers discover requests; an AI-style demo ranks matches. This is the page itself, not a concept presentation.

## Run and verify
- Node.js >=22.13. Use `npx pnpm@11.19.0 install --frozen-lockfile`, then `npx pnpm@11.19.0 dev`.
- Run `npx pnpm@11.19.0 build` before handoff. The prototype uses React 19, TypeScript, Tailwind v4 and Vinext/Cloudflare's local Vite runtime.
- The root `/` redirects to `/request-property`.
- A local copy has `.openai/hosting.json` with a null project ID to avoid editing the existing privately hosted Site by accident. Use a separate hosting destination if asked to publish this copy.

## Required experience
- Arabic-first RTL and English LTR; language toggle updates document direction. All bilingual strings and option labels live in `src/content.ts`.
- Brand name is lowercase `belmazad.com`. Preserve its primary blue #0077B5, orange #F56E3D, supporting neutral palette, and Arabic tagline `السوق في إيدك.`. CSS tokens live in `src/styles.css`; do not hardcode new colours in components. Licensed Neue Haas Grotesk is for future production; free stand-ins are in CSS.
- Feed posts mean *buyer requests*, never properties for sale. Keep requests anonymised; never expose contact details on public cards or matching results.
- Buy only. Buyer flow has eight stages: goal, type, multi-area location, budget, requirements, must-haves, notes/contact, public review. Land and other non-residential types hide bedrooms, bathrooms and floor.
- Mobile layout has a sticky action bar and a full-height wizard. Keyboard focus and reduced-motion rules matter.
- Seller matching ranks the sample buyer requests; the scores are a deterministic front-end demo, not a real AI service. Do not imply real persisted leads or live matching.
- Submission and seller responses are local demo states. Do not say a request was actually sent. Live backend, auth, payments, notifications, rental, seller dashboard and real listings are outside this reference.

## Source map
- `src/Marketplace.tsx` — page UI, wizard, demand feed, seller demo and dialogs.
- `src/content.ts` — all Arabic/English copy and option labels.
- `src/data.ts` — typed PropertyRequest, sample requests, options, validation and match scoring.
- `src/api.ts` — `submitRequest()` is the single future buyer API integration point.
- `src/styles.css` — semantic tokens, typography, responsive layout and motion.
- `app/request-property/page.tsx`, `app/page.tsx`, `app/layout.tsx` — route and metadata.
- `HANDOFF.md` — integration notes and demo limits.

## Practical cautions
- The `public/property.webp` image is illustrative and depicts a villa in Mallorca. Its reuse rights were not established; replace it with an approved Belmazad asset before production.
- The text logo is a prototype; replace with approved logo files and licensed fonts before production.
- Apply server-side validation and moderation before publishing free-text buyer notes. Keep private contact fields separate from the public request model.
- The site's existing private URL may require the original ChatGPT account. This archive is the transferable source.

When asked to change a feature, edit the source directly, run the build, and explain the result and any remaining demo limitation succinctly.
