# belmazad.com — Request a property

Arabic-first, English-toggle front-end reference. React 19 + TypeScript + Tailwind v4, served by the Sites Vinext starter. No application backend, authentication, payments, or real AI.

## Source map
- `app/page.tsx`: preview redirect to `/request-property`.
- `src/Marketplace.tsx`: demand feed, detail/response dialogs, 8-step buyer wizard, seller matching, confirmation.
- `src/content.ts`: Arabic/English interface dictionary and translated option labels.
- `src/styles.css`: semantic palette, glass surfaces, responsive rules, motion and isolated Arabic/Latin font stacks. Replace `--font-brand`, `--font-latin`, and Arabic font with the licensed production assets as appropriate.
- `src/data.ts`: typed `PropertyRequest`, validation, options, sample demand, deterministic matching function.
- `src/api.ts`: `submitRequest()` is the future buyer API boundary. Returns a demo reference without transmitting or storing contact information.

## Agency integration
1. Replace the text wordmark with the approved brand logo and licensed brand fonts.
2. Replace sample demand with API data, preserving private contact fields separately from the public projection.
3. Implement `submitRequest()` with the agreed API and server validation. Apply moderation to public free text to avoid personal contact information appearing there.
4. Connect seller response submission through Belmazad; the current dialog acknowledges the demo locally only.
5. Replace `matchRequests()` with the matching service. Current score: type 25, location 25, area 15, budget 20, features 10, bedrooms/bathrooms 5. Results require matching type and >=65 points. Notes are collected for buyer review; semantic interpretation requires the future AI service.
6. Confirm production privacy terms, consent, transaction fees and moderation before launch. Publishing a buyer request is described as free; no claim of a free transaction is made.

## Demo behaviors
- Language switches document `lang` and `dir` without clearing form state.
- Buy-only flow; land and other non-residential types remove bedrooms/bathrooms/floor.
- Multi-area filtering, typed budgets and upper-budget slider, required field validation.
- Public review excludes name/phone; editable steps and full-screen success with copyable summary.
- Seller inputs influence calculated results; no-match and loading states provided.
- Reduced motion honored; keyboard focus styles and Radix focus-trapped dialogs.
- Submitted requests join the feed and matching pool in session memory. All state resets on reload.

## Image
`public/property.webp`: illustrative villa photograph, actual location Mallorca, from https://loveshack.ev-mallorca.com/ . Direct source: https://loveshack.ev-mallorca.com/hubfs/LS%20Loveshack%2011/LS%20Slider/LS11_SLIDER_01.webp . It is not an Egyptian listing. Replace with a licensed Belmazad property asset for production; no reuse license was established.
