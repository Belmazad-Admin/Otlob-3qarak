import type {PropertyRequest} from './data';
// The sole future API integration point. Demo data is never transmitted or persisted.
export async function submitRequest(request:PropertyRequest):Promise<{reference:string;request:PropertyRequest}>{await new Promise(resolve=>setTimeout(resolve,650));return {reference:`BM-DEMO-${Date.now().toString().slice(-6)}`,request:{...request}};}
