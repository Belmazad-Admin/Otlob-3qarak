import Marketplace from '@/src/Marketplace';
export default function Page(){return <Marketplace/>;}
